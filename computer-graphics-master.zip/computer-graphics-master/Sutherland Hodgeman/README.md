# Sutherland Hodgeman

## Steps
1. Draw the boundary
2. Draw the shape
3. Call all 4 clips with x and y array
	1. out to in condition
	2. out to out condition
	3. in to out condition
	4. in to in condition
